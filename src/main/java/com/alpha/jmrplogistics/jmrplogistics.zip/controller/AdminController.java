package com.alpha.jmrplogistics.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alpha.jmrplogistics.dto.DriverDto;
import com.alpha.jmrplogistics.dto.LoadingDto;
import com.alpha.jmrplogistics.dto.OrderDto;
import com.alpha.jmrplogistics.dto.ResponseStructure;
import com.alpha.jmrplogistics.dto.UnloadingDto;
import com.alpha.jmrplogistics.dto.UserDto;
import com.alpha.jmrplogistics.entity.Address;
import com.alpha.jmrplogistics.entity.Cargo;
import com.alpha.jmrplogistics.entity.Carrier;
import com.alpha.jmrplogistics.entity.Driver;
import com.alpha.jmrplogistics.entity.Loading;
import com.alpha.jmrplogistics.entity.Order;
import com.alpha.jmrplogistics.entity.Truck;
import com.alpha.jmrplogistics.entity.Unloading;
import com.alpha.jmrplogistics.entity.User;
import com.alpha.jmrplogistics.services.AddressService;
import com.alpha.jmrplogistics.services.CargoService;
import com.alpha.jmrplogistics.services.CarrierService;
import com.alpha.jmrplogistics.services.DriverService;
import com.alpha.jmrplogistics.services.LoadingService;
import com.alpha.jmrplogistics.services.OrderService;
import com.alpha.jmrplogistics.services.TruckService;
import com.alpha.jmrplogistics.services.UnloadingService;
import com.alpha.jmrplogistics.services.UserService;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    @Autowired
    private DriverService driverService;

    @Autowired
    private CargoService cargoService;

    @Autowired
    private TruckService truckService;

    @Autowired
    private OrderService orderService;

    @Autowired
    private CarrierService carrierService;

    @Autowired
    private LoadingService loadingService;

    @Autowired
    private UnloadingService unloadingService;

    @Autowired
    private UserService userService;

    @Autowired
    private AddressService addressService;

    // Truck Endpoints
    @PostMapping("/trucks")
    public ResponseEntity<ResponseStructure<Map<String, Object>>> createTruck(@RequestBody Truck truck) {
        return truckService.addTruck(truck);
    }

    @GetMapping("/trucks/{id}")
    public ResponseEntity<ResponseStructure<Truck>> getTruckById(@PathVariable("id") int truckId) {
        return truckService.getTruckById(truckId);
    }

    @DeleteMapping("/trucks/{id}")
    public ResponseEntity<ResponseStructure<String>> removeTruck(@PathVariable("id") int truckId) {
        return truckService.deleteTruck(truckId);
    }

    @GetMapping("/trucks")
    public ResponseEntity<ResponseStructure<List<Truck>>> listAllTrucks() {
        return truckService.getAllTrucks();
    }

    // Order Endpoints
    @PostMapping("/orders")
    public ResponseEntity<ResponseStructure<Order>> createOrder(@RequestBody OrderDto orderDto) {
        return orderService.addOrder(orderDto);
    }

    @GetMapping("/orders/orderId/{id}")
    public ResponseEntity<ResponseStructure<Order>> getOrderById(@PathVariable("id") int orderId) {
        return orderService.getOrderById(orderId);
    }

    @DeleteMapping("/orders/{id}")
    public ResponseEntity<ResponseStructure<String>> removeOrder(@PathVariable("id") int orderId) {
        return orderService.deleteOrder(orderId);
    }

    @GetMapping("/orders")
    public ResponseEntity<ResponseStructure<List<Order>>> listAllOrders() {
        return orderService.getAllOrders();
    }

    // Carrier Endpoints
    @PostMapping("/carriers")
    public ResponseEntity<ResponseStructure<Carrier>> createCarrier(@RequestBody Carrier carrier) {
        return carrierService.addCarrier(carrier);
    }

    @GetMapping("/carriers/{id}")
    public ResponseEntity<ResponseStructure<Carrier>> getCarrierById(@PathVariable("id") int carrierId) {
        return carrierService.getCarrierById(carrierId);
    }

    @DeleteMapping("/carriers/{id}")
    public ResponseEntity<ResponseStructure<String>> removeCarrier(@PathVariable("id") int carrierId) {
        return carrierService.deleteCarrier(carrierId);
    }

    @GetMapping("/carriers")
    public ResponseEntity<ResponseStructure<List<Carrier>>> listAllCarriers() {
        return carrierService.getAllCarriers();
    }

    // Loading Endpoints
    @PostMapping("/loadings")
    public ResponseEntity<ResponseStructure<Map<String, Object>>> createLoading(@RequestBody LoadingDto loadingDto) {
        return loadingService.addLoading(loadingDto);
    }

    @GetMapping("/loadings/{id}")
    public ResponseEntity<ResponseStructure<Loading>> getLoadingById(@PathVariable("id") int loadingId) {
        return loadingService.getLoadingById(loadingId);
    }

    @DeleteMapping("/loadings/{id}")
    public ResponseEntity<ResponseStructure<String>> removeLoading(@PathVariable("id") int loadingId) {
        return loadingService.deleteLoading(loadingId);
    }

    @GetMapping("/loadings")
    public ResponseEntity<ResponseStructure<List<Loading>>> listAllLoadings() {
        return loadingService.getAllLoadings();
    }

    // Unloading Endpoints
    @PostMapping("/unloadings")
    public ResponseEntity<ResponseStructure<Map<String, Object>>> createUnloading(@RequestBody UnloadingDto unloadingDto) {
        return unloadingService.addUnloading(unloadingDto);
    }

    @GetMapping("/unloadings/{id}")
    public ResponseEntity<ResponseStructure<Unloading>> getUnloadingById(@PathVariable("id") int unloadingId) {
        return unloadingService.getUnloadingById(unloadingId);
    }

    @DeleteMapping("/unloadings/{id}")
    public ResponseEntity<ResponseStructure<String>> removeUnloading(@PathVariable("id") int unloadingId) {
        return unloadingService.deleteUnloading(unloadingId);
    }

    @GetMapping("/unloadings")
    public ResponseEntity<ResponseStructure<List<Unloading>>> listAllUnloadings() {
        return unloadingService.getAllUnloadings();
    }

    // User Endpoints
    @PostMapping("/users")
    public ResponseEntity<ResponseStructure<Map<String, Object>>> createUser(@RequestBody UserDto userDto) {
        return userService.addUser(userDto);
    }

    @GetMapping("/users/{id}")
    public ResponseEntity<ResponseStructure<User>> getUserById(@PathVariable("id") int userId) {
        return userService.getUserById(userId);
    }

    @PutMapping("/users/{id}")
    public ResponseEntity<ResponseStructure<User>> updateUser(@PathVariable("id") int userId, @RequestBody UserDto userDto) {
        return userService.updateUser(userId, userDto);
    }

    @DeleteMapping("/users/{id}")
    public ResponseEntity<ResponseStructure<String>> removeUser(@PathVariable("id") int userId) {
        return userService.deleteUser(userId);
    }

    @GetMapping("/users")
    public ResponseEntity<ResponseStructure<List<User>>> listAllUsers() {
        return userService.getAllUsers();
    }

    // Cargo Endpoints
    @PostMapping("/cargo")
    public ResponseEntity<ResponseStructure<Map<String, Object>>> createCargo(@RequestBody Cargo cargo) {
        return cargoService.addCargo(cargo);
    }

    @GetMapping("/cargo/{id}")
    public ResponseEntity<ResponseStructure<Cargo>> getCargoById(@PathVariable("id") int cargoId) {
        return cargoService.getCargoById(cargoId);
    }

    @DeleteMapping("/cargo/{id}")
    public ResponseEntity<ResponseStructure<String>> removeCargo(@PathVariable("id") int cargoId) {
        return cargoService.deleteCargo(cargoId);
    }

    @GetMapping("/cargo")
    public ResponseEntity<ResponseStructure<List<Cargo>>> listAllCargo() {
        return cargoService.getAllCargo();
    }

    // Address Endpoints
    @PostMapping("/addresses")
    public ResponseEntity<ResponseStructure<Map<String, Object>>> createAddress(@RequestBody Address address) {
        return addressService.addAddress(address);
    }

    @GetMapping("/addresses/{id}")
    public ResponseEntity<ResponseStructure<Address>> getAddressById(@PathVariable("id") int addressId) {
        return addressService.getAddressById(addressId);
    }

    @DeleteMapping("/addresses/{id}")
    public ResponseEntity<ResponseStructure<String>> removeAddress(@PathVariable("id") int addressId) {
        return addressService.deleteAddress(addressId);
    }

    @GetMapping("/addresses")
    public ResponseEntity<ResponseStructure<List<Address>>> listAllAddresses() {
        return addressService.getAllAddresses();
    }

    // Driver Endpoints
    @PostMapping("/drivers")
    public ResponseEntity<ResponseStructure<Map<String, Object>>> createDriver(@RequestBody DriverDto driverDto) {
        return driverService.addDriver(driverDto);
    }

    @GetMapping("/drivers/{id}")
    public ResponseEntity<ResponseStructure<Driver>> getDriverById(@PathVariable("id") int driverId) {
        return driverService.getDriverById(driverId);
    }

    @DeleteMapping("/drivers/{id}")
    public ResponseEntity<ResponseStructure<String>> removeDriver(@PathVariable("id") int driverId) {
        return driverService.deleteDriver(driverId);
    }

    @GetMapping("/drivers")
    public ResponseEntity<ResponseStructure<List<Driver>>> listAllDrivers() {
        return driverService.getAllDrivers();
    }
}
