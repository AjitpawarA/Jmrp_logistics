package com.alpha.jmrplogistics.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.alpha.jmrplogistics.dao.CarrierDao;
import com.alpha.jmrplogistics.dto.ResponseStructure;
import com.alpha.jmrplogistics.entity.Carrier;

import java.util.List;
import java.util.Optional;

@Service
public class CarrierService {

    @Autowired
    private CarrierDao carrierDao;

    public ResponseEntity<ResponseStructure<Carrier>> addCarrier(Carrier carrier) {
        ResponseStructure<Carrier> responseStructure = new ResponseStructure<>();
        Carrier savedCarrier = carrierDao.addCarrier(carrier);

        if (savedCarrier != null) {
            responseStructure.setStatuscode(HttpStatus.CREATED.value());
            responseStructure.setMessage("Carrier saved successfully.");
            responseStructure.setData(savedCarrier);
            return new ResponseEntity<>(responseStructure, HttpStatus.CREATED);
        } else {
            responseStructure.setStatuscode(HttpStatus.BAD_REQUEST.value());
            responseStructure.setMessage("Carrier could not be saved.");
            responseStructure.setData(null);
            return new ResponseEntity<>(responseStructure, HttpStatus.BAD_REQUEST);
        }
    }

    public ResponseEntity<ResponseStructure<Carrier>> getCarrierById(int id) {
        ResponseStructure<Carrier> responseStructure = new ResponseStructure<>();
        Optional<Carrier> carrier = carrierDao.findById(id);

        if (carrier.isPresent()) {
            responseStructure.setStatuscode(HttpStatus.OK.value());
            responseStructure.setMessage("Carrier found");
            responseStructure.setData(carrier.get());
            return new ResponseEntity<>(responseStructure, HttpStatus.OK);
        } else {
            responseStructure.setStatuscode(HttpStatus.NOT_FOUND.value());
            responseStructure.setMessage("Carrier not found");
            responseStructure.setData(null);
            return new ResponseEntity<>(responseStructure, HttpStatus.NOT_FOUND);
        }
    }

    public ResponseEntity<ResponseStructure<String>> deleteCarrier(int id) {
        ResponseStructure<String> responseStructure = new ResponseStructure<>();
        Optional<Carrier> optionalCarrier = carrierDao.findById(id);

        if (optionalCarrier.isPresent()) {
            carrierDao.deleteById(id);
            responseStructure.setStatuscode(HttpStatus.OK.value());
            responseStructure.setMessage("Carrier deleted successfully");
            responseStructure.setData("Deleted carrier with ID: " + id);
            return new ResponseEntity<>(responseStructure, HttpStatus.OK);
        } else {
            responseStructure.setStatuscode(HttpStatus.NOT_FOUND.value());
            responseStructure.setMessage("Carrier not found");
            responseStructure.setData(null);
            return new ResponseEntity<>(responseStructure, HttpStatus.NOT_FOUND);
        }
    }

    public ResponseEntity<ResponseStructure<List<Carrier>>> getAllCarriers() {
        ResponseStructure<List<Carrier>> responseStructure = new ResponseStructure<>();
        List<Carrier> carriers = carrierDao.findAll(); // Ensure your DAO has a findAll method

        responseStructure.setStatuscode(HttpStatus.OK.value());
        responseStructure.setMessage("Carriers retrieved successfully");
        responseStructure.setData(carriers);
        return new ResponseEntity<>(responseStructure, HttpStatus.OK);
    }
}
