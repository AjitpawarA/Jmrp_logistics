package com.alpha.jmrplogistics.services;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.alpha.jmrplogistics.dao.AddressDao;
import com.alpha.jmrplogistics.dao.LoadingDao;
import com.alpha.jmrplogistics.dto.LoadingDto;
import com.alpha.jmrplogistics.dto.ResponseStructure;
import com.alpha.jmrplogistics.entity.Address;
import com.alpha.jmrplogistics.entity.Loading;
import com.alpha.jmrplogistics.exception.AddressNotFoundException;
import com.alpha.jmrplogistics.exception.LoadingNotFoundException;
import com.alpha.jmrplogistics.repo.LoadingRepository;

@Service
public class LoadingService {

    @Autowired
    private LoadingRepository loadingRepository;

    @Autowired
    private LoadingDao loadingDao;

    @Autowired
    private AddressDao addressDao;

    
    
    private Map<String, String> validateLoadingDto(LoadingDto loadingDto) {
        Map<String, String> errorMessage = new HashMap<>();
        if (loadingDto.getCompanyname() == null || loadingDto.getCompanyname().isEmpty()) {
            errorMessage.put("companyName", "Company name should not be null or empty");
        }
        if (loadingDto.getLoadingdate() == null) {
            errorMessage.put("loadingDate", "Loading date should not be null");
        }
        if (loadingDto.getLoadingtime() == null) {
            errorMessage.put("loadingTime", "Loading time should not be null");
        }
        if (loadingDto.getAddressId() == 0) {
            errorMessage.put("addressId", "Address ID should not be zero");
        }
        return errorMessage;
    }

    // Add a new loading entity
    public ResponseEntity<ResponseStructure<Map<String, Object>>> addLoading(LoadingDto loadingDto) {
        ResponseStructure<Map<String, Object>> responseStructure = new ResponseStructure<>();
        Map<String, String> errorMessage = validateLoadingDto(loadingDto);

        if (!errorMessage.isEmpty()) {
            Map<String, Object> errors = new HashMap<>();
            errors.put("errors", errorMessage);

            responseStructure.setStatuscode(HttpStatus.BAD_REQUEST.value());
            responseStructure.setMessage("Invalid Inputs");
            responseStructure.setData(errors);

            return new ResponseEntity<>(responseStructure, HttpStatus.BAD_REQUEST);
        }

        Address address = addressDao.findById(loadingDto.getAddressId())
                .orElseThrow(() -> new AddressNotFoundException("Address not found with ID: " + loadingDto.getAddressId()));

        Loading loadingToBeSaved = new Loading();
        loadingToBeSaved.setCompanyName(loadingDto.getCompanyname());
        loadingToBeSaved.setLoadingDate(loadingDto.getLoadingdate());
        loadingToBeSaved.setLoadingTime(loadingDto.getLoadingtime());
        loadingToBeSaved.setAddress(address);

        Loading savedLoading = loadingDao.addLoading(loadingToBeSaved);

        Map<String, Object> savedLoadings = new HashMap<>();
        savedLoadings.put("data", savedLoading);

        responseStructure.setStatuscode(HttpStatus.CREATED.value());
        responseStructure.setMessage("Loading saved successfully");
        responseStructure.setData(savedLoadings);

        return new ResponseEntity<>(responseStructure, HttpStatus.CREATED);
    }

    // Get a loading entity by ID
    public ResponseEntity<ResponseStructure<Loading>> getLoadingById(int id) {
        ResponseStructure<Loading> responseStructure = new ResponseStructure<>();

        Loading loading = loadingDao.findById(id)
                .orElseThrow(() -> new LoadingNotFoundException("Loading not found with ID: " + id));

        responseStructure.setStatuscode(HttpStatus.OK.value());
        responseStructure.setMessage("Loading found");
        responseStructure.setData(loading);
        return new ResponseEntity<>(responseStructure, HttpStatus.OK);
    }

    // Delete a loading entity by ID
    public ResponseEntity<ResponseStructure<String>> deleteLoading(int id) {
        ResponseStructure<String> responseStructure = new ResponseStructure<>();

        Loading loading = loadingDao.findById(id)
                .orElseThrow(() -> new LoadingNotFoundException("Loading not found with ID: " + id));
        loadingRepository.deleteById(id);

        responseStructure.setStatuscode(HttpStatus.OK.value());
        responseStructure.setMessage("Loading deleted successfully");
        responseStructure.setData("Deleted successfully");
        return new ResponseEntity<>(responseStructure, HttpStatus.OK);
    }

    // Get all loading entities
    public ResponseEntity<ResponseStructure<List<Loading>>> getAllLoadings() {
        ResponseStructure<List<Loading>> responseStructure = new ResponseStructure<>();
        List<Loading> loadings = loadingDao.findall();

        responseStructure.setStatuscode(HttpStatus.OK.value());
        responseStructure.setMessage("Loadings retrieved successfully");
        responseStructure.setData(loadings);
        return new ResponseEntity<>(responseStructure, HttpStatus.OK);
    }
}
