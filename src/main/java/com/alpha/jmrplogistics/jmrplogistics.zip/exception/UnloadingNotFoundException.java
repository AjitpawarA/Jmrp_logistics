package com.alpha.jmrplogistics.exception;
public class UnloadingNotFoundException extends RuntimeException {
    public UnloadingNotFoundException(String message) {
        super(message);
    }
}