package com.alpha.jmrplogistics.exception;

public class OrderNotFoundException extends Exception {
	
}
