package com.alpha.jmrplogistics.exception;
public class TruckAdditionException extends RuntimeException {
    public TruckAdditionException(String message) {
        super(message);
    }
}