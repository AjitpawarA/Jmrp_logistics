package com.alpha.jmrplogistics.exception;

public class DriverAdditionException extends Exception {
	public DriverAdditionException(String message) {
        super(message);
    }
}
