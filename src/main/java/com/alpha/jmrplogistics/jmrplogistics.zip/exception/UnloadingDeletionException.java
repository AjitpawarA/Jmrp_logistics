package com.alpha.jmrplogistics.exception;
public class UnloadingDeletionException extends RuntimeException {
    public UnloadingDeletionException(String message) {
        super(message);
    }
}