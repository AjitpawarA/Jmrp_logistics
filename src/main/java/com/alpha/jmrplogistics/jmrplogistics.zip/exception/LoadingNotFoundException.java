package com.alpha.jmrplogistics.exception;

public class LoadingNotFoundException extends RuntimeException {
    public LoadingNotFoundException(String message) {
        super(message);
    }
}