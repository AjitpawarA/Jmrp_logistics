package com.alpha.jmrplogistics.dto;

import java.time.LocalDate;

public class OrderDto {
	
	private LocalDate dateoforder;
	private String orderstatus;
	private Double freightcost;
	private String additionalinfo;
	private long cargoId;
	private long carrierID;
	private int loadingUserid;
	private int unloadingUserid;
	private int loadingId;
	private int unloadingId;
	
	
	public int getLoadingId() {
		return loadingId;
	}
	public void setLoadingId(int loadingId) {
		this.loadingId = loadingId;
	}
	public int getUnloadingId() {
		return unloadingId;
	}
	public void setUnloadingId(int unloadingId) {
		this.unloadingId = unloadingId;
	}
	public int getLoadingUserid() {
		return loadingUserid;
	}
	public void setLoadingUserid(int loadingUserid) {
		this.loadingUserid = loadingUserid;
	}
	public int getUnloadingUserid() {
		return unloadingUserid;
	}
	public void setUnloadingUserid(int unloadingUserid) {
		this.unloadingUserid = unloadingUserid;
	}
	public LocalDate getDateoforder() {
		return dateoforder;
	}
	public void setDateoforder(LocalDate dateoforder) {
		this.dateoforder = dateoforder;
	}
	public String getOrderstatus() {
		return orderstatus;
	}
	public void setOrderstatus(String orderstatus) {
		this.orderstatus = orderstatus;
	}
	public Double getFreightcost() {
		return freightcost;
	}
	public void setFreightcost(Double freightcost) {
		this.freightcost = freightcost;
	}
	public String getAdditionalinfo() {
		return additionalinfo;
	}
	public void setAdditionalinfo(String additionalinfo) {
		this.additionalinfo = additionalinfo;
	}
	public long getCargoId() {
		return cargoId;
	}
	public void setCargoId(long cargoId) {
		this.cargoId = cargoId;
	}
	public long getCarrierID() {
		return carrierID;
	}
	public void setCarrierID(long carrierID) {
		this.carrierID = carrierID;
	}
	
	
}
