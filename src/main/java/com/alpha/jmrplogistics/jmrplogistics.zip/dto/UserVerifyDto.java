package com.alpha.jmrplogistics.dto;

public class UserVerifyDto {

    private int id;
    private String userpassword;
    
    
	public int getid() {
		return id;
	}
	public void setid(int id) {
		this.id = id;
	}
	public String getUserpassword() {
		return userpassword;
	}
	public void setUserpassword(String userpassword) {
		this.userpassword = userpassword;
	}

    
    
}
