package com.alpha.jmrplogistics.dto;

public class LoadingDto {

    private String companyname;
    private String loadingdate;
    private String loadingtime;

    private int addressId;

	public String getCompanyname() {
		return companyname;
	}

	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}

	public String getLoadingdate() {
		return loadingdate;
	}

	public void setLoadingdate(String loadingdate) {
		this.loadingdate = loadingdate;
	}

	public String getLoadingtime() {
		return loadingtime;
	}

	public void setLoadingtime(String loadingtime) {
		this.loadingtime = loadingtime;
	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}
    
    
}
