package com.alpha.jmrplogistics.dto;

public class DriverDto {
	private String drivername;
    private String driverphonenumber;
    private int carrierId;
    private int TruckId;
    
    
	public String getDrivername() {
		return drivername;
	}
	public void setDrivername(String drivername) {
		this.drivername = drivername;
	}
	public String getDriverphonenumber() {
		return driverphonenumber;
	}
	public void setDriverphonenumber(String driverphonenumber) {
		this.driverphonenumber = driverphonenumber;
	}
	public int getCarrierId() {
		return carrierId;
	}
	public void setCarrierId(int carrierId) {
		this.carrierId = carrierId;
	}
	public int getTruckId() {
		return TruckId;
	}
	public void setTruckId(int truckId) {
		TruckId = truckId;
	}
    
    
}
