package com.alpha.jmrplogistics.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.alpha.jmrplogistics.entity.Unloading;

public interface UnloadingRepository extends JpaRepository<Unloading, Integer>{

}
