package com.alpha.jmrplogistics.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.alpha.jmrplogistics.entity.Truck;

public interface TruckRepository extends JpaRepository<Truck, Integer>{

}
